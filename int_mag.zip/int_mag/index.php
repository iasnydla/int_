<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<h3>Категории</h3>
<?php
require_once 'bd.php'; // подключаем скрипт

$link = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link));

$query ="SELECT * FROM cat";

$result = mysqli_query($link, $query) or die("Ошибка " . mysqli_error($link));
if($result)
{
    $rows = mysqli_num_rows($result); // количество полученных строк

    echo "<table><tr><th>Номер</th><th>Название</th></tr>";

    for ($i = 0 ; $i < $rows ; ++$i)
    {
        $row = mysqli_fetch_row($result);
        echo "<tr>";
        for ($j = 0 ; $j < 3 ; ++$j) echo "<td>$row[$j]</td>";
        
        echo "</tr>";
    }
    echo "</table>";

    // очищаем результат
    mysqli_free_result($result);
}

mysqli_close($link);
?>
</body>
</html>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<?php
require_once 'bd.php'; // подключаем скрипт

if(isset($_POST['name'])){

    // подключаемся к серверу
    $link = mysqli_connect($host, $user, $password, $database)
    or die("Ошибка " . mysqli_error($link));

    // экранирования символов для mysql
    $name = htmlentities(mysqli_real_escape_string($link, $_POST['name']));

    // создание строки запроса
    $query ="INSERT INTO cat VALUES(NULL, '$name')";

    // выполняем запрос
    $result = mysqli_query($link, $query) or die("Ошибка " . mysqli_error($link));
    if($result)
    {
        echo "<span style='color:blue;'>Данные добавлены</span>";
    }
    // закрываем подключение
    mysqli_close($link);
}
?>
<h4>Добавить новую категорию</h4>
<form method="POST">
    <label for="name">Введите название:</label><br />
        <input type="text" name="name" /><br />
    <input type="submit" value="Добавить">
</form>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <meta charset=utf-8" />
</head>

<body>

<h4>Введите название категории, которую хотите удалить</h4>

<form method="post" action="delete.php">
    <label for="name">Название категории:</label><br />
    <input id="name" name="name" type="text" size="30" /><br />
    <input type="submit" name="Remove" value="Удалить" />
</form>

</body>
</html>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>

<?php

try {
// Открываем соединение, указываем адрес сервера, имя бд, имя пользователя и пароль,
// также сообщаем серверу в какой кодировке должны вводится данные в таблицу бд.
    $db = new PDO("mysql:host=localhost;dbname=db", $username = 'root', $password = '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
// Устанавливаем атрибут сообщений об ошибках (выбрасывать исключения)
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
    echo "Ошибка при создании записи в базе данных: " . $e->getMessage();
}
$db = null;
?>

<h4>Редактирование данных таблицы "Категории"</h4>
<form action="update_c.php" method="POST">
    <div>
        <label for="id">Выберите номер строки *:</label>
        <input type="number" id="id" name="id" required>
    </div>
    <div>
        <label for="name">Название категории:</label>
        <input type="text" id="name" name="name">
    </div>

    <input type="submit" value="Обновить запись">
</form>
</body>
</html>





<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<br>
<br>
<br>
<h3>Товары</h3>
<?php
require_once 'bd.php'; // подключаем скрипт

$link1 = mysqli_connect($host, $user, $password, $database)
or die("Ошибка " . mysqli_error($link1));

$query ="SELECT * FROM products";

$result1 = mysqli_query($link1, $query) or die("Ошибка " . mysqli_error($link1));
if($result1)
{
    $rows1 = mysqli_num_rows($result1); // количество полученных строк

    echo "<table><tr><th>Номер</th><th>Название</th><th>Описание</th><th>Цена</th><th>Фото</th></tr>";

    for ($i = 0 ; $i < $rows1 ; ++$i)
    {
        $row = mysqli_fetch_row($result1);
        echo "<tr>";
        for ($j = 0 ; $j < 3 ; ++$j) echo "<td>$row[$j]</td>";
        echo "</tr>";
    }
    echo "</table>";

    // очищаем результат
    mysqli_free_result($result1);
}

mysqli_close($link1);
?>
</body>
</html>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<?php
require_once 'bd.php'; // подключаем скрипт

if(isset($_POST['name_p'])&& isset($_POST['disc'])&& isset($_POST['price'])&& isset($_POST['photo'])){

    // подключаемся к серверу
    $link1 = mysqli_connect($host, $user, $password, $database)
    or die("Ошибка " . mysqli_error($link1));

    // экранирования символов для mysql
    $name_p = htmlentities(mysqli_real_escape_string($link1, $_POST['name_p']));
    $disc = htmlentities(mysqli_real_escape_string($link1, $_POST['disc']));
    $price = htmlentities(mysqli_real_escape_string($link1, $_POST['price']));
    $photo = htmlentities(mysqli_real_escape_string($link1, $_POST['photo']));

    // создание строки запроса
    $query ="INSERT INTO products VALUES(NULL, '$name_p','$disc','$price','$photo')";

    // выполняем запрос
    $result1 = mysqli_query($link1, $query) or die("Ошибка " . mysqli_error($link1));
    if($result1)
    {
        echo "<span style='color:blue;'>Данные добавлены</span>";
    }
    // закрываем подключение
    mysqli_close($link1);
}
?>
<h4>Добавить новый товар</h4>
<form method="POST">
    <p>Введите название:<br>
        <input type="text" name="name_p" /></p>
    <p>Описание: <br>
        <input type="text" name="disc" /></p>
    <p>Цена: <br>
        <input type="text" name="price" /></p>
    <p>Фото: <br>
        <input type="text" name="photo" /></p>
    <input type="submit" value="Добавить">
</form>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <meta charset=utf-8" />
</head>

<body>

<h4>Введите название товара, который хотите удалить</h4>

<form method="post" action="delete.php">
    <label for="name_">Название товара:</label><br />
    <input id="name_p" name="name_p" type="text" size="30" /><br />
    <input type="submit" name="Remove" value="Удалить" />
</form>

<?php
try {
// Открываем соединение, указываем адрес сервера, имя бд, имя пользователя и пароль,
// также сообщаем серверу в какой кодировке должны вводится данные в таблицу бд.
    $db = new PDO("mysql:host=localhost;dbname=db", $username = 'root', $password = '', array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
// Устанавливаем атрибут сообщений об ошибках (выбрасывать исключения)
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e) {
    echo "Ошибка при создании записи в базе данных: " . $e->getMessage();
}
$db = null;
?>

<h4>Редактирование данных</h4>
<form action="update.php" method="POST">
    <div>
        <label for="id_p">Выберите номер строки *:</label>
        <input type="number" id="id_p" name="id_p" required>
    </div>
    <div>
        <label for="name_p">Название товара:</label>
        <input type="text" id="name_p" name="name_p">
    </div>
    <div>
        <label for="disc">Описание:</label>
        <input type="text" id="disc" name="disc">
    </div>
    <div>
        <label for="price">Цена:</label>
        <input type="text" id="price" name="price">
    </div>
    <div>
        <label for="photo">Фото:</label>
        <input type="text" id="photo" name="photo">
    </div>
    <input type="submit" value="Обновить запись">
</form>
</body>
</html>