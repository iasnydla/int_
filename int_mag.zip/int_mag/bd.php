<?php

$host = 'localhost'; // адрес сервера
$database = 'db'; // имя базы данных
$user = 'root'; // имя пользователя
$password = ''; // пароль
