<!DOCTYPE html>
<html>
<head>
    <meta charset=utf-8" />
</head>
<body>

<?php
$db = mysqli_connect('localhost', 'root', '', 'db')
or die('Error connecting to MySQL server.');

$name = $_POST['name'];

$query = "DELETE FROM cat WHERE name = '$name'";
mysqli_query($db, $query)
or die('Error querying database.');

echo 'Customer removed: ' . $name;

mysqli_close($db);

?>

</body>
</html>


<!DOCTYPE html>
<html>
<head>
    <meta charset=utf-8" />
</head>
<body>

<?php
$db = mysqli_connect('localhost', 'root', '', 'db')
or die('Error connecting to MySQL server.');

$name_p = $_POST['name_p'];

$query = "DELETE FROM products WHERE name_p = '$name_p'";
mysqli_query($db, $query)
or die('Error querying database.');

echo 'Customer removed: ' . $name_p;

mysqli_close($db);

?>

</body>
</html>