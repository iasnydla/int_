<?php
$db_server = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "db";
try {
    // Открываем соединение, указываем адрес сервера, имя бд, имя пользователя и пароль,
    // также сообщаем серверу в какой кодировке должны вводится данные в таблицу бд.
    $db = new PDO("mysql:host=localhost;dbname=db", $username = 'root', $password = '',array(PDO::MYSQL_ATTR_INIT_COMMAND=>"SET NAMES utf8"));
    // Устанавливаем атрибут сообщений об ошибках (выбрасывать исключения).
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Переносим данные из полей формы в переменные.
    $id_p =       $_POST['id_p'];
    $name_p =    $_POST['name_p'];
    $disc =   $_POST['disc'];
    $price =    $_POST['price'];
    $photo = $_POST['photo'];

    // Если пользователь не указал (номер Id) какую запись будем редактировать,
    // то прерываем выполнение кода.
    if(empty($id_p)){
        echo "Вы не задали номер строки для обновления данных!";
        return;
    }

    // Составвлям массив колонок для запроса обновления.
    // Если поле формы не пустое, то его значение будет добавлено в запрос.
    $update_columns = array();
    if(trim($name_p) !== "")   { $update_columns[] = "name_p = :name_p"; }
    if(trim($disc) !== "")  { $update_columns[] = "disc = :disc"; }
    if(trim($price) !== "")   { $update_columns[] = "price = :price"; }
    if(trim($photo) !== ""){ $update_columns[] = "photo = :photo"; }

    // Если есть хоть одно заполненное поле формы,
    // то составляем запрос.
    if(sizeof($update_columns > 0)){
        // Запрос на создание записи в таблице
        $sql = "UPDATE products SET " . implode(", ", $update_columns) . " WHERE id_p=:id_p";
        // Перед тем как выполнять запрос предлагаю убедится, что он составлен без ошибок.
        // echo $sql;
        // Например, если в форме заполнены поля: название, автор книги и номер Id=1,
        // то запрос должен выглядеть следующим образом:
        // "UPDATE products SET name_p = :name_p, disc = :disc WHERE id=:id"

        // Подготовка запроса.
        $statement = $db->prepare($sql);

        // Привязываем к псевдо переменным реальные данные,
        // если они существуют (пользователь заполнил поле в форме).
        $statement->bindParam(":id_p", $id_p);
        if(trim($name_p) !== ""){
            $statement->bindParam(":name_p", $name_p);
        }
        if(trim($disc) !== ""){
            $statement->bindParam(":disc", $disc);
        }
        if(trim($price) !== ""){
            $statement->bindParam(":price", $price);
        }
        if(trim($photo) !== ""){
            $statement->bindParam(":photo", $photo);
        }

        // Выполняем запрос.
        $statement->execute();

        echo "Запись c номером: " . $id_p . " успешно обновлена!";
    }
}

catch(PDOException $e) {
    echo "Ошибка при обновлении записи в базе данных: " . $e->getMessage();
}

// Закрываем соединение.
$db = null;
?>


<
